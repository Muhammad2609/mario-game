package game;

import city.cs.engine.UserView;
import city.cs.engine.World;

import javax.swing.*;
import java.awt.*;

public class GameView extends UserView {

    private Mario mario; //mario field
    private final Image Heart; //heart image
    private final int height; //height  of image
    private final int width; // width of image
    GameLevel currentLevel; //gamelevel field

    //Gameview constructor
    public GameView(GameLevel w, Mario mario, int width, int height) {
        super(w, width, height);
        currentLevel = w;
        Heart = new ImageIcon("data/Heart.gif").getImage();
        this.mario = mario;
        this.height = height;
        this.width = width;
    }

    //Override method to change the world
    @Override
    public void setWorld(World w){
        super.setWorld(w);
        currentLevel = (GameLevel) w;
    }

    //Adds image to the screen
    public void paintForeground(Graphics2D count) {
        Font font = new Font("Arial", Font.BOLD, 15); //font for the display
        count.setFont(font); //sets the font
        count.setColor(Color.white);// sets the colour
        count.drawString("COINS COLLECTED: " + mario.getCoinCount(), 10, 30); //display the coins collected
        if(currentLevel.getMario().getHealth()==3){ //adds the number of heart there is depending on the level
            count.drawImage(Heart,700,10,50,50,this); //here is the heart being displayed on screen
            count.drawImage(Heart,740,10,50,50,this);
            count.drawImage(Heart,780,10,50,50,this);
            count.dispose();
        }
        else if(currentLevel.getMario().getHealth() == 2){
            count.drawImage(Heart,700,10,50,50,this);
            count.drawImage(Heart,740,10,50,50,this);
            count.dispose();
        }
        else if(currentLevel.getMario().getHealth() == 1){
            count.drawImage(Heart,740,10,50,50,this);
            count.dispose();
        }
        count.dispose();
    }

        //method to paint the background
        @Override
        protected void paintBackground (Graphics2D g){
            g.drawImage(currentLevel.getBackground(), 0, 0, this);
        } //adds the background and displays it


    //updates the character when it changes levels
    public void updatemario(Mario m){
        this.mario = m;
    }


    }
