package game;


import city.cs.engine.*;
import org.jbox2d.common.Vec2;

import java.util.concurrent.Semaphore;

    public class LavaSensor extends StaticBody implements SensorListener, StepListener {

        private static final Shape LavaSensor = new BoxShape(23,0.25f);
        private Lava lava;
        private final Mario mario;
        private boolean inLava;
        private final Sensor sensor;


        public LavaSensor(GameLevel w) {
            super(w);
            sensor = new Sensor(this,LavaSensor);
            sensor.addSensorListener(this);
            this.mario = w.getMario();
            w.addStepListener(this);



        }


        @Override
        public void beginContact(SensorEvent sensorEvent) {
            inLava = true;

        }

        @Override
        public void endContact(SensorEvent sensorEvent) {
            inLava = false;
        }

        @Override
        public void preStep (StepEvent stepEvent) {
            if (inLava) {
                mario.setPosition(new Vec2(17, -6));
                mario.setHealth(mario.getHealth() - 1);
                System.out.println(mario.getHealth());
                if (mario.getHealth() == 0) {
                    mario.destroy();
                }

            }
        }

        @Override
        public void postStep(StepEvent stepEvent) {

        }
    }
