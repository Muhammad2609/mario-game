package game;

import city.cs.engine.Shape;
import city.cs.engine.BoxShape;
import city.cs.engine.SoundClip;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Level3 extends GameLevel{


    private Monster monster;
    private Mario mario;
    private Lava lava;
    private final LavaSensor lavaSensor;

    Image background;


    public Level3(Game game){
        super(game);

        background = new ImageIcon("data/Background3.jpeg").getImage();


        //int targetCoins = 6

        // make a suspended platform

        Platform platform   = new Platform(this, new Vec2(15,-11f), 0); //Starting bottom right
        Platform platform1  = new Platform(this, new Vec2(2.5F,-11f), 0); //2nd bottom
        Platform platform2  = new Platform(this, new Vec2(-7.5f,-11f), 0); //3rd bottom

        Platform platform3  = new Platform(this, new Vec2(-17.5f,-6f), 0); //Step to second floor
        Platform platform4  = new Platform(this, new Vec2(-7,-1f), 0); //Second floor first jump
        Platform platform5  = new Platform(this, new Vec2(4,-1f), 0); //Second floor second jump
        Platform platform6  = new Platform(this, new Vec2(17,-1f), 0); //Second floor third jump

        Platform platform7  = new Platform(this, new Vec2(12,4f), 0); //Step to third floor
        Platform platform8  = new Platform(this, new Vec2(0,6f), 0); //Third floor first jump
        Platform platform9  = new Platform(this, new Vec2(-9,6f), 0); //Third floor second jump
        Platform platform10 = new Platform(this, new Vec2(-18,6f), 0); //Third floor third jump


        // Ground platform
        Shape Ground = new BoxShape(20f,0.05f);
        StaticBody floor = new StaticBody( this, Ground);
        floor.setPosition(new Vec2(0,-15f));
        floor.setLineColor(new Color ( 1, true));

        lavaSensor = new LavaSensor(this);
        lavaSensor.setPosition(new Vec2(0,-12f));

        //Coins
        new Coin(this).setPosition(new Vec2(-7.5f,-10f)); //3rd bottom
        new Coin(this).setPosition(new Vec2(17,-1f)); //second floor third jump
        new Coin(this).setPosition(new Vec2(-9,7f)); //second floor third jump
        new Coin(this).setPosition(new Vec2(-18,7f)); //second floor fourth jump


        getGhost().setPosition(new Vec2(1.5F,7));
        getMario().setPosition(new Vec2(15,-6));
        getMonster().setPosition(new Vec2(1F,2));
        getMonster().setMoveone(true);
        getMonster2().setPosition(new Vec2(5f,-10));
        MonsterCollision Collision1 = new MonsterCollision(getMario());
        getMonster2().addCollisionListener(Collision1);
        getMonster().addCollisionListener(Collision1);
        MonsterStepListener MSP = new MonsterStepListener(getMonster2());
        //System.out.println(getMonster2().getPosition());

        if(getMario().getCoinCount() == 4){
            System.exit(0);
        }

    }

    @Override
    public boolean isComplete() {
        return getMario().getCoinCount() >= 4;
    }

    @Override
    public Image getBackground() {
        return background;
    }

    @Override
    public String getName() {
        return "Level 3";
    }
}
