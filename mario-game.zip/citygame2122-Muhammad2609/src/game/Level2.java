package game;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.SoundClip;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Level2 extends GameLevel{


private Monster monster;
private Mario mario;
Image background;


    public Level2(Game game){
        super(game);

        background = new ImageIcon("data/Background2.jpeg").getImage();



        //int targetCoins = 6


        //make a ground platform
        Shape shape = new BoxShape(23, 0.5f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -12f));

        // make a suspended platform
        Platform platform  = new Platform(this, new Vec2(0,6f), 0); //Centre Top Platform
        Platform platform1 = new Platform(this, new Vec2(0,-7.5f), 0); //Centre Bottom Platform

        Platform platform2 = new Platform(this, new Vec2(-14,7f), 0); //Far Top Left Platform
        Platform platform3 = new Platform(this, new Vec2(-5,1f), 0); //Left Top Platform
        Platform platform4 = new Platform(this, new Vec2(-8,-4f), 0); //Left Middle Platform
        Platform platform5 = new Platform(this, new Vec2(-16,-9.25f), 0); //Left Bottom Platform

        Platform platform6 = new Platform(this, new Vec2(14,7f), 0); //Far Top Right Platform
        Platform platform7 = new Platform(this, new Vec2(5,1f), 0); //Right Top Platform
        Platform platform8 = new Platform(this, new Vec2(8,-4f), 0); //Right Middle Platform
        Platform platform9 = new Platform(this, new Vec2(16,-9.25f), 0); //Right bottom Platform

        //Coins
        new Coin(this).setPosition(new Vec2(-9,-9f));
        new Coin(this).setPosition(new Vec2(9,-4f));
        new Coin(this).setPosition(new Vec2(-14,7f));
        new Coin(this).setPosition(new Vec2(-14f,-7f));

        getGhost().setPosition(new Vec2(-3,-5));
        getMario().setPosition(new Vec2(6,-6));
        getMonster().setPosition(new Vec2(6,8));
        getMonster().setMoveone(true);
        getMonster2().setPosition(new Vec2(-1f,8));
        MonsterCollision Collision1 = new MonsterCollision(getMario());
        getMonster2().addCollisionListener(Collision1);
        getMonster().addCollisionListener(Collision1);
        MonsterStepListener MSP = new MonsterStepListener(getMonster2());
    }

    @Override
    public boolean isComplete() {
        return getMario().getCoinCount() >= 4;
    }

    @Override
    public Image getBackground() {
        return background;
    }
    //public Monster getMonster(){return monster;}

    @Override
    public String getName() {
        return "Level 2";
    }
}
