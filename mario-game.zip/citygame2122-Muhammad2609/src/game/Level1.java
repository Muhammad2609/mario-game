package game;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.SoundClip;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Level1 extends GameLevel{


Image background;


    public Level1(Game game){
        super(game);

        background = new ImageIcon("data/Background1.jpeg").getImage();


        //make a ground platform
        Shape shape = new BoxShape(23, 0.5f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -12f));

        // make a suspended platform
        Platform platform = new Platform(this, new Vec2(-9,-6.5f), 0); //Left Platform
        Platform platform2 = new Platform(this, new Vec2(9,-6.5f), 0); //Right Platform
        Platform platform3 = new Platform(this, new Vec2(0,-0.75f), 0); //Top Platform
        //Platform platform4 = new Platform(this, new Vec2(4,5), 0);

        new Coin(this).setPosition(new Vec2(-9,-6.5f)); //Left Coin
        new Coin(this).setPosition(new Vec2(9,-6.5f)); //Right Coin
        new Coin(this).setPosition(new Vec2(0,-0.75f)); //Top Coin

        getGhost().setPosition(new Vec2(-3,-9));
        getMario().setPosition(new Vec2(4,-9));
    }

    @Override
    public boolean isComplete() {
        return getMario().getCoinCount() >= 3;
    }

    @Override
    public Image getBackground() {
        return background;
    }

    @Override
    public String getName() {
        return "Level 1";
    }



}
