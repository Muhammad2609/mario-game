package game;

import city.cs.engine.StepEvent;
import city.cs.engine.StepListener;

public class MonsterStepListener implements StepListener {

    private final Monster monster;
    private boolean movetwo;

    public MonsterStepListener(Monster m){
        this.monster = m;
    }


    @Override
    public void preStep(StepEvent stepEvent) {

    }

    @Override
    public void postStep(StepEvent stepEvent) {

        if(monster.getPosition().x <=-1f){
            monster.startWalking(2);
        }
        else if(monster.getPosition().x >=3.5){
            monster.startWalking(-2);
        }
    }

    public boolean isMovetwo() {
        return movetwo;
    }

    public void setMovetwo(boolean movetwo) {
        this.movetwo = movetwo;
    }
}
