package game;
import java.util.List;
import java.util.Random;
import city.cs.engine.*;

    public class Ghost extends Walker implements StepListener {
        private static final Shape ghostShape = new BoxShape(1, 2); //shape of the ghost
        private static final BodyImage image = new BodyImage("data/Ghost.png", 4); //ghost image
        private final Random random; // assigns a random value
        private int Count; //used to change direction
        private final int Health; //health of the ghost


        public Ghost(World world) {
            super(world, ghostShape);
            this.addImage(image);
            random = new Random();
            System.out.println(random.nextInt());
            Count = 0; //given count a value
            Health = 0; //given health a value
        }

        @Override
        public void preStep(StepEvent stepEvent) {

        }

        @Override
        public void postStep(StepEvent stepEvent) {
            //System.out.println(getPosition().x);
            if (getPosition().x > -1) { //shows the position of the ghost
                stopWalking();
                startWalking(-2f); // start to move the character the opposite way
                List<AttachedImage> allIm = this.getImages(); //stores the image in a list
                for(AttachedImage im:allIm){
                    im.flipHorizontal(); // changes the direction of the image
                }
                Count = 1; //changes the value of count

            } else if (getPosition().x <= -3) {
                stopWalking();
                startWalking(2f);
                List<AttachedImage> allIm = this.getImages();
                if(Count == 1) { //once the value is changed
                    for (AttachedImage im : allIm) {
                        im.flipHorizontal();
                    }
                }
            }
        }
    }
