package game;
import java.util.List;
import java.util.Random;
import city.cs.engine.*;

public class Monster extends Walker implements StepListener {
    private static final Shape monsterShape = new PolygonShape(-1.34f,0.06f, -0.88f,-1.75f, 0.81f,-1.78f, 1.55f,-1.19f, 0.83f,1.06f, -0.17f,1.18f, -1.34f,0.07f); //monster shape

    private static final BodyImage image = new BodyImage("data/Monster.png", 4); //monster image
    private final Random random; //assign a random value
    private final int Count; //monster count
    private final int Health; //monster health
    private boolean moveone; //moves the character
    private boolean movetwo; // testing purposes


    public Monster(World world) {
        super(world, monsterShape);
        this.addImage(image);
        random = new Random();
        System.out.println(random.nextInt());
        Count = 0; //assigned a count value
        Health = 0; //assigned a health value
        moveone = false; //assigned a boolean value
        movetwo = false; //assigned a boolean value
    }

    Monster(World world,boolean T){
        super(world, monsterShape);
        this.addImage(image);
        random = new Random();
        System.out.println(random.nextInt());
        Count = 0;
        Health = 0;
        this.movetwo = T;

    }

    @Override
    public void preStep(StepEvent stepEvent) {

    }

    @Override
    public void postStep(StepEvent stepEvent) {
        if(movetwo){ //testing purposes
            System.out.println("working");
        }

        if(moveone) {
            if (getPosition().x <= 6) { //if postion of the monster matches the if statement speed of character changes
                startWalking(2);
            } else if (getPosition().x >= 8) {//if postion of the monster matches the if statement speed of character changes
                startWalking(-2f);
            }
        }


    }

    public void setMoveone(boolean moveone) {
        this.moveone = moveone;
    }



}
