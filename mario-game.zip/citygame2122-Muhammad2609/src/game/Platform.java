package game;
import city.cs.engine.*;
import org.jbox2d.common.Vec2;


    public class Platform extends StaticBody{

        private final BodyImage platformImage = new BodyImage("data/Platform.png", 1.5f);
        private final Shape platformShape = new BoxShape(3.4f, 0.75f);
        private final StaticBody platform;

        public Platform(World world, Vec2 position,float degrees) {
            super(world);
            platform = new StaticBody(world, platformShape);
            platform.addImage(platformImage);
            platform.setPosition(position);
            platform.setAngleDegrees(degrees);
        }

    }


