package game;

import city.cs.engine.*;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

public class FireBall extends DynamicBody {
    private static final Shape FireBallShape = new PolygonShape(-0.084f,0.369f, 0.166f,0.052f, 0.32f,-0.194f, -0.105f,-0.335f, -0.492f,-0.201f, -0.579f,0.085f, -0.404f,0.336f); //shape of fireball
    public static final BodyImage FireBall = new BodyImage("data/FireballRight.png"); //fireball image
    public FireBall(World w) {
        super(w,FireBallShape);
        this.addImage(FireBall); //adds image of fireball
        setAlwaysOutline(true);
    }

    private static SoundClip fireballSound; //fireball sound

    static {
        try {
            fireballSound = new SoundClip("data/FireballSound.wav"); //file of the fireball sound
            System.out.println("Fireball sound");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }


    // method that plays the sound and destroy its own fireball
    @Override
    public void destroy() {
        fireballSound.play(); //play the sound
        super.destroy(); //destroy's the fireball
    }
}
