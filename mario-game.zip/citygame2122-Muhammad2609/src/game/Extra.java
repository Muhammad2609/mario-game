
        /*new Coin() = new Coin(this);
        getCoin().setPosition(new Vec2(-9,-4f));

        new Coin() = new Coin(this);
        new Coin().setPosition(new Vec2(9,-4f));

        new Coin() = new Coin(this);
        new Coin().setPosition(new Vec2(0,1f));


        view = new GameView(currentLevel, currentLevel.getMario(), 601, 343);

        //optional: uncomment this to make a debugging view
        JFrame debugView = new DebugViewer(currentLevel, 601, 343);

LEVEL 3 TING

       lavaSensor = new LavaSensor(this);
        lavaSensor.setPosition(new Vec2(0,-12f));*/


        //lava = new Lava(this, new Vec2(0,-12F),0);
        /*LavaCollision lavaCollision = new LavaCollision(getMario());
        getLava().addCollisionListener(lavaCollision);


package game;
import city.cs.engine.*;
import org.jbox2d.common.Vec2;


public class Wall extends StaticBody{
    //make wallImage here
    BodyImage wallImage = new BodyImage("data/BrickWall.png",27f);
    // make  wallShape here
    private static final Shape wallShape = new BoxShape(0.5f, 10);

    // constructor
    public Wall(World world, Vec2 position) {

        super(world, wallShape);
        setPosition(position);
        addImage(wallImage);

    }

}

         */
