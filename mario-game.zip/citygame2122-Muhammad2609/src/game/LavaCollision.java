package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import city.cs.engine.StaticBody;

public class LavaCollision implements CollisionListener {


    private final Mario mario;
    public LavaCollision(Mario m){
        this.mario = m;
    }

    @Override
    public void collide(CollisionEvent collisionEvent) {
        if (collisionEvent.getOtherBody() instanceof Mario) {
            mario.decrementLifeCount();
            mario.setHealth(mario.getHealth()-1);
            if (mario.getHealth() == 0) {
                collisionEvent.getOtherBody().destroy();
            }
        }
    }
}
