package game;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class SaveLoad {
    public static void save(String fileName, GameLevel level)
            throws IOException {
        boolean append = false;

        FileWriter writer = null;
        try {
            writer = new FileWriter(fileName, append);

            writer.write(level.getName());

        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    public static GameLevel load(String fileName, Game game) throws IOException {

        FileReader fr = null;
        BufferedReader reader = null;

        try {
            fr = new FileReader(fileName);
            reader = new BufferedReader(fr);

            String line = reader.readLine();
            GameLevel level = null;
            if (line.equals("Level 1")) {
                level = new Level1(game);
            }
            else if (line.equals("Level 2")) {
                level = new Level2(game);
            }
            else if (line.equals("Level 3")) {
                level = new Level3(game);
            }


            line = reader.readLine();
            return level;

        }finally {
            if (reader != null) {
                reader.close();
            }
            if (fr != null) {
                fr.close();
            }
        }
    }
}