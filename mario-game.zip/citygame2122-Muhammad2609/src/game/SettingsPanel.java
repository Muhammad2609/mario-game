package game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SettingsPanel {
    public JPanel mainPanel;
    private JButton returnButton;
    private JButton instructionsButton;

    Game game;
    private  GameLevel currentlevel;


    public SettingsPanel(Game game) {


        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.transitionToControlPanel();
            }
        });
        instructionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.transitionToInstructions();

            }
        });




    }
}
