package game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Controlpanel {
    public JPanel Mainpanel;
    private JButton restartButton;
    private JButton playstopButton;
    private JButton settingsButton;
    private JButton exitButton;
    private JButton saveButton;
    private JButton loadButton;
    private Game game;
    private int paused;
    public Controlpanel(Game game) {
        paused = 0;
        settingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.transitionToSettings();

            }
        });
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.ExitControlPanel();
            }
        });
        restartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.restart();
                game.start();
            }
        });
        playstopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (paused == 0) {
                    game.pause();
                    paused++;
                }
                else if (paused == 1) {
                    game.resume();
                    paused = paused - 1;
                }
            }
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    SaveLoad.save("data/saveFile.txt", game.currentLevel);
                }
                catch (IOException ee){
                    ee.printStackTrace();
                }
            }
        });
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    GameLevel levelLoad = SaveLoad.load("data/saveFile.txt", game);
                    game.levelSetter(levelLoad);
                }
                catch (IOException ee){
                    ee.printStackTrace();
                }

            }
        });
    }
}

