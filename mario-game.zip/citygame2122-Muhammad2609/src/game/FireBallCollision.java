package game;

import city.cs.engine.*;

public class FireBallCollision implements CollisionListener {

    private final Ghost ghost;
    private final World world;
    private final Mario mario;
    private final Monster monster;

    public FireBallCollision(Monster monster,Ghost ghost, World w, Mario m) {
        this.ghost = ghost;
        this.world = w;
        this.mario = m;
        this.monster = monster;
    }

    @Override
    public void collide(CollisionEvent collisionEvent) {
        if (collisionEvent.getOtherBody() instanceof Ghost) {
            mario.setShootCount(mario.getShootCount() + 1);
            collisionEvent.getReportingBody().destroy();
            if (mario.getShootCount() == 3) {
                collisionEvent.getOtherBody().destroy();
                mario.setShootCount(0);
            }
        }
        //collisionEvent.getReportingBody.destroy();
        if (collisionEvent.getOtherBody() instanceof StaticBody) {
            collisionEvent.getReportingBody().destroy();
        }

        if (collisionEvent.getOtherBody() instanceof Monster) {
            mario.setShootCount(mario.getShootCount() + 1);
            collisionEvent.getReportingBody().destroy();
            System.out.println(mario.getShootCount());
            if (mario.getShootCount() == 3) {
                collisionEvent.getOtherBody().destroy();
                mario.setShootCount(0);
            }
        }




    }

}
