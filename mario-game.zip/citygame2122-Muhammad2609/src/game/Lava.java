package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;


/*** the class for lava */
public class Lava extends DynamicBody  {


    /*** the image for the lava**/
    private final BodyImage lavaImage = new BodyImage("data/Lava.gif", 44f);
    /*** Shape of lava**/
    private final Shape lavaShape = new BoxShape(23f, 0.75f);
    /*** Body of lava**/
    private final StaticBody lava;

    public Lava(World world, Vec2 position, float degrees) {
        super(world);
        lava = new StaticBody(world, lavaShape);
        lava.addImage(lavaImage);
        lava.setPosition(position);
        lava.setAngleDegrees(degrees);
        lava.setClipped(true);
    }


}
