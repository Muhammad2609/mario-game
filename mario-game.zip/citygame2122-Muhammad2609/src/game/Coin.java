package game;

import city.cs.engine.*;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;


/*** class for coin*/
public class Coin extends DynamicBody {
    /*** Shape of coin**/
    private static final Shape coinShape = new PolygonShape(-0.047f, 0.943f, 0.847f, 0.305f, 0.762f, -0.656f, 0.506f, -0.897f, -0.766f, -0.902f, -1.074f, -0.14f, -0.823f, 0.65f);
    /*** Image of coin**/
    private static final BodyImage image = new BodyImage("data/Coin.gif", 2);
    /*** Sound of coin**/
    private static SoundClip coinSound;

    static {
        try {
            coinSound = new SoundClip("data/CoinSound.mp3");
            System.out.println("Coin sound");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }
    }

    /*** override method that plays the sound and destroy the body*/
    @Override
    public void destroy() {
        coinSound.play();
        super.destroy();
    }

    public Coin(World world) {
        super(world, coinShape);
        addImage(image);


    }
}