package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Controller implements KeyListener {

    private static final float WALKING_SPEED = 4f; //walking speed
    private Mario mario; //mario class
    private final Game game; //game class

    public Controller(Game game,Mario mario) {
        this.mario = mario;
        this.game = game;
        //
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        //System.out.println("dfh");


        int code = e.getKeyCode(); //gets what the user is typing
        if (code == KeyEvent.VK_A) { //checks whether keyboard typed is 'a'
            mario.startWalking(-WALKING_SPEED); //sets the speed of mario
        }
        else if (code == KeyEvent.VK_D) {
            mario.startWalking(WALKING_SPEED);
        }
        else if (code == KeyEvent.VK_W){
            mario.jump(10); // makes mario jump
        }else if (code == KeyEvent.VK_ESCAPE) {
            game.toggleMenu(); // shows the menu
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_A) {
            mario.stopWalking();
        }
        if (code == KeyEvent.VK_D) {
            mario.stopWalking();
        }
    }

    public void updateMario(Mario newMario){
        mario = newMario;
    }
}
