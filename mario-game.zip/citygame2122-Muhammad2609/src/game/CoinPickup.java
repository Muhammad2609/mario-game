package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;

public class CoinPickup implements CollisionListener{

    private Mario mario; //mario field
    GameLevel currentLevel; //gamelevel field
    Game game;// game field

    // coinpickup class's constructor
    public CoinPickup(GameLevel level, Game game, Mario m){
        this.mario = m;
        currentLevel = level;
        this.game = game;
        //this.mario = level.getMario();
    }


    // override method
    @Override
    public void collide(CollisionEvent e){
        if (e.getOtherBody() instanceof Coin) {
            mario.setCoinCount(mario.getCoinCount()+1); // increase count to 1
            e.getOtherBody().destroy();// destroys coin


        }
        if (currentLevel.isComplete()) //check whether level is complete
            game.goToNextLevel(); //moves to next level
    }

    public void UpdateMario(Mario m){
        this.mario = m;
    }
}