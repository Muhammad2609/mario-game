package game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameInstructions {
    public JPanel MainPanel;
    private JTextField instructionsTextField;
    private JButton controlsButton;
    private JButton returnButton;
    private final Game game;

    public GameInstructions(Game game) {
        this.game = game;
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.transitiontoSettings();

            }
        });
        controlsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.transitionToControls();
            }
        });
    }

}
