package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.awt.*;
import java.io.IOException;

/**
 * Class for Mario
 */
public class Mario extends Walker {
	/** shape of mario*/
	private static final Shape marioShape = new BoxShape(1,1.75f);
	/** mario image */
	private static final BodyImage leftimage = new BodyImage("data/Mario_Left.gif", 4);
	/** mario image */
	private static final BodyImage rightimage = new BodyImage("data/Mario_Right.gif", 4);
	/** mario direction*/
	private String direction;
	/** mario score*/
	private int coinCount;
	/** ghost field*/
	private final Ghost ghost;
	/** mario shoot count*/
	private int ShootCount;
	/** mario health */
	private int Health;
	/** monster field */
	private  Monster monster;
	/*private static SoundClip lifeDownSound;

	static {
		try {
			lifeDownSound = new SoundClip("data/LifeDownSound.mp3");
			System.out.println("Life Down sound");
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
			System.out.println(e);
		}
	}

	@Override
	public void destroy() {
		lifeDownSound.play();
		super.destroy();
	}
*/
	public Mario(World world, Ghost g) {
		super(world, marioShape);
		addImage(leftimage);
		direction = "left";
		coinCount= 0;
		this.ghost = g;
		ShootCount = 0;
		Health = 3;



	}

	/*** getter method that returns the number of coins he has**/
	public int getCoinCount() {
		return coinCount;
	}

	/*** Method that allows mario to walk **/
	public void startWalking(float speed) {
		super.startWalking(speed);
		if (speed < 0) {
			this.removeAllImages();
			this.addImage(leftimage);
			direction = "left";
		} else {
			this.removeAllImages();
			this.addImage(rightimage);
			direction = "right";
		}
	}

		/*** method that allows mario to shoot fireballs**/
		public void shoot(Vec2 t){
		FireBall fireball = new FireBall(this.getWorld());
		FireBallCollision fireBallCollision = new FireBallCollision(monster,ghost,this.getWorld(),this);
		fireball.addCollisionListener(fireBallCollision);
			Vec2 dir = t.sub(this.getPosition());
			dir.normalize();
			if(direction.equals("left")){
				fireball.setPosition(this.getPosition().add(dir.mul(0.2f)));
				fireball.setLinearVelocity(dir.mul(30));
				fireball.removeAllImages();
				fireball.addImage(new BodyImage("data/FireballRight.png",1));

			}else {
				fireball.setPosition(this.getPosition().add(dir.mul(0.2f)));
				fireball.setLinearVelocity(dir.mul(30));
				fireball.removeAllImages();
				fireball.addImage(new BodyImage("data/FireballRight.png",1));
			}
		}

	/*** a getter method for the shoot count**/
	public int getShootCount() {
		return ShootCount;
	}

	/*** a setter method for the shoot count**/
	public void setShootCount(int shootCount) {
		ShootCount = shootCount;
	}

	/*** a getter method for the health**/
	public int getHealth() {
		return Health;
	}

	/*** a setter method for the health**/
	public void setHealth (int health) {
		Health = health;
	}

	/*** a setter method for the coincount **/
	public void setCoinCount(int coinCount){
		this.coinCount = coinCount;
	}

	/*** a method to reduce mario health*/
	public void decrementLifeCount(){
		Health--;
	}

}




