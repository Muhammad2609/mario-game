package game;
import city.cs.engine.DebugViewer;
import city.cs.engine.SoundClip;

import java.awt.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;

/**
 * Your main game entry point
 */

public class Game {

    public GameLevel currentLevel;
    GameView view;
    Controller controller;
    Shooting shoot;
    private SoundClip gameMusic;
    private  boolean menuVisible;
    private final Controlpanel controlpanel;
    private final SettingsPanel settingsPanel;
    private final GameInstructions instructionsPanel;
    private final Controls controlsPanel;
    private final JFrame frame;

    public Object goToNextLevel;

    //private SoundClip gameMusic;

    /**
     * Initialise a new Game.
     */
    public Game() {

        //1. make an empty game world
        //World world = new World();
        currentLevel = new Level1(this);

        try {
            gameMusic = new SoundClip("data/BackgroundMusic.mp3");   // Open an audio input stream
            gameMusic.loop();  // continuous playback (looping)
            gameMusic.setVolume(0.25);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            //code in here will deal with any errors
            //that might occur while loading/playing sound
            System.out.println(e);
        }

        Mario m = currentLevel.getMario();

        menuVisible= false;
        //2. make a view to look into the game world
        //UserView view = new UserView(world, 500, 500);
        view = new GameView(currentLevel, m, 850, 500);
        //view.setZoom(17);


        shoot = new Shooting(currentLevel.getMario(), view);
        view.addMouseListener(shoot);


        view.addMouseListener(new GiveFocus(view));
        controller = new Controller(this,currentLevel.getMario());
        view.addKeyListener(controller);
        //optional: draw a 1-metre grid over the view
        // view.setGridResolution(1);

        currentLevel.addStepListener(currentLevel.getGhost());
        //3. create a Java window (frame) and add the game
        //   view to it

        frame = new JFrame("City Game");
        frame.add(view);
        // enable the frame to quit the application
        // when the x button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
        // finally, make the frame visible
        frame.setVisible(true);


        // start our game world simulation!
        currentLevel.start();

        //optional: uncomment this to make a debugging view
        //JFrame debugView = new DebugViewer(currentLevel, 850, 500);
        controlpanel =  new Controlpanel(this);
        settingsPanel = new SettingsPanel(this);
        instructionsPanel = new GameInstructions(this);
        controlsPanel = new Controls(this);

        /*try {
            gameMusic = new SoundClip("data/BackgroundMusic.mp3");   // Open an audio input stream
            gameMusic.loop();  // continuous playback (looping)
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            //code in here will deal with any errors
            //that might occur while loading/playing sound
            System.out.println(e);
        } */
    }

    /**
     * Run the game.
     */
    public static void main(String[] args) {

        new Game();
    }

    public void levelSetter(GameLevel level){
        currentLevel.stop();
        currentLevel = level;
        controller.updateMario(currentLevel.getMario());
        shoot.UpdateMario(currentLevel.getMario());
        view.updatemario(currentLevel.getMario());
        view.setWorld(currentLevel);
        currentLevel.addStepListener(currentLevel.getGhost());
        currentLevel.addStepListener(currentLevel.getMonster());
        currentLevel.addStepListener(currentLevel.getMonster2());
        currentLevel.addStepListener(new MonsterStepListener(currentLevel.getMonster2()));
        currentLevel.addStepListener(new MonsterStepListener(currentLevel.getMonster()));
        currentLevel.start();
    }


    public void goToNextLevel() {
        System.out.println("Transition to next level");

        if (currentLevel instanceof Level1){

            currentLevel.stop();
            gameMusic.stop();
            currentLevel = new Level2(this);

            try {
                gameMusic = new SoundClip("data/UndergroundMusic.mp3");   // Open an audio input stream
                gameMusic.loop();  // continuous playback (looping)
                gameMusic.setVolume(0.25);
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                //code in here will deal with any errors
                //that might occur while loading/playing sound
                System.out.println(e);
            }


            //JFrame debugViewer = new DebugViewer(currentLevel, 850,500);
            view.setWorld(currentLevel);
            controller.updateMario(currentLevel.getMario());
            shoot.UpdateMario(currentLevel.getMario());
            currentLevel.addStepListener(currentLevel.getGhost());
            view .updatemario(currentLevel.getMario());
            currentLevel.addStepListener(currentLevel.getMonster());
            currentLevel.addStepListener(new MonsterStepListener(currentLevel.getMonster2()));
            // currentLevel.pickup.UpdateMario(currentLevel.getMario());      might need later currently redundant
            currentLevel.start();

        }
        else if (currentLevel instanceof Level2){
            currentLevel.stop();
            gameMusic.stop();
            currentLevel = new Level3(this);

            try {
                gameMusic = new SoundClip("data/lava.wav");   // Open an audio input stream
                gameMusic.loop();  // continuous playback (looping)
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                //code in here will deal with any errors
                //that might occur while loading/playing sound
                System.out.println(e);
            }

            //JFrame debugViewer = new DebugViewer(currentLevel, 850,500);
            view.setWorld(currentLevel);
            controller.updateMario(currentLevel.getMario());
            shoot.UpdateMario(currentLevel.getMario());
            currentLevel.addStepListener(currentLevel.getGhost());
            currentLevel.addStepListener(currentLevel.getMonster());
            currentLevel.addStepListener(currentLevel.getMonster2());
            currentLevel.addStepListener(new MonsterStepListener(currentLevel.getMonster2()));
            view.updatemario(currentLevel.getMario());


            currentLevel.start();
        }


        else if (currentLevel instanceof Level3){
            gameMusic.stop();
            //JFrame debugViewer = new DebugViewer(currentLevel, 850,500);
            view.setWorld(currentLevel);
            controller.updateMario(currentLevel.getMario());
            shoot.UpdateMario(currentLevel.getMario());
            currentLevel.addStepListener(currentLevel.getGhost());
            System.out.println("Game Over!");
            System.exit(0);
        }

    }


    public void toggleMenu() {
        if (menuVisible) {
            frame.remove(controlpanel.Mainpanel);
            menuVisible = false;
            frame.pack();

        } else {
            frame.add(controlpanel.Mainpanel, BorderLayout.WEST);
            menuVisible = true;
            frame.pack();

        }
    }
    public void transitionToSettings(){

        frame.remove(controlpanel.Mainpanel);
        frame.add(settingsPanel.mainPanel,BorderLayout. WEST);
        frame.pack();
    }
    public void transitionToControlPanel(){
        frame.remove(settingsPanel.mainPanel);
        frame.add(controlpanel.Mainpanel,BorderLayout.WEST);
        frame.pack();

    }
    public void ExitControlPanel() {
        frame.remove(controlpanel.Mainpanel);
        frame.pack();
    }


    public void start(){
        currentLevel = new Level1(this);
        gameMusic.stop();

        try {
            gameMusic = new SoundClip("data/BackgroundMusic.mp3");   // Open an audio input stream
            gameMusic.loop();  // continuous playback (looping)
            gameMusic.setVolume(0.25);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            //code in here will deal with any errors
            //that might occur while loading/playing sound
            System.out.println(e);
        }


        controller.updateMario(currentLevel.getMario());
        shoot.UpdateMario(currentLevel.getMario());
        view.updatemario(currentLevel.getMario());
        view.setWorld(currentLevel);
        currentLevel.addStepListener(currentLevel.getGhost());

        currentLevel.start();

    }
    public void restart(){
        System.out.println("Nice");
        currentLevel.stop();
    }



    public void transitiontoSettings() {
        frame.remove(controlpanel.Mainpanel);
        frame.remove(instructionsPanel.MainPanel);
        frame.add(settingsPanel.mainPanel, BorderLayout.WEST);
        frame.pack();

    }

    public void transitionToInstructions(){
        frame.remove(settingsPanel.mainPanel);
        frame.add(instructionsPanel.MainPanel, BorderLayout.WEST);
        frame.pack();
    }
 public void transitionToControls(){
     frame.remove(instructionsPanel.MainPanel);
     frame.add(controlsPanel.MainPanel, BorderLayout.WEST);
     frame.pack();

 }

 public void transitiontoGameInstructions(){
     frame.remove(settingsPanel.mainPanel);
     frame.remove(controlsPanel.MainPanel);
     frame.add(instructionsPanel.MainPanel, BorderLayout.WEST);
     frame.pack();

 }
    public void pause(){
        currentLevel.stop();
        frame.pack();
    }
    public void resume(){

        currentLevel.start();
        frame.pack();
    }



}
