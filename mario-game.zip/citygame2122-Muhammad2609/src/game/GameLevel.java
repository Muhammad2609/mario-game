package game;

import org.jbox2d.common.Vec2;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import city.cs.engine.World;

import java.awt.*;

public abstract class GameLevel extends World {
private final Mario mario;
private final Ghost ghost;
private Monster monster;
private Monster monster2;
//private Ghost ghost2;
private Coin coin;
private Coin coin2;
private Coin coin3;
private Lava lava;


	public GameLevel(Game game) {
		super();
		// populate the GameWorld with bodies (ex: platforms, collectibles, characters)


        //make a ceiling platform
        Shape shape2 = new BoxShape(23, 0.5f);
        StaticBody ceiling = new StaticBody(this, shape2);
        ceiling.setPosition(new Vec2(0f, 13f));



        //make two walls
        /*Wall wall1 = new Wall(this, new Vec2(-22f, -1)); //Left Wall
        Wall wall2 = new Wall(this, new Vec2(22f, -1)); //Right Wall
        wall1.setClipped(true);
        wall2.setClipped(true);
        */
        //private static final Shape wallShape = new BoxShape(0.5f, 10);
        Shape shape = new BoxShape(0.5f, 10f);
        StaticBody wall = new StaticBody(this, shape);
        StaticBody wall1 = new StaticBody(this, shape);
        wall.setPosition(new Vec2(-22f, -1f));
        wall1.setPosition(new Vec2(22f, -1f));





        //make a character (with an overlaid image)
        ghost = new Ghost(this);

        if(this instanceof Level2) {
            monster = new Monster(this);
            monster2 = new Monster(this,true);
            //monster2.setMovetwo(true);

        }

        if(this instanceof Level3) {
            monster = new Monster(this);
            monster2 = new Monster(this,true);
        }

        //ghost.setPosition(new Vec2(-3,-5)); In levels

        //monster = new Monster(this);

        //ghost2 = new Ghost(this);
        //ghost2.setPosition(new Vec2(1,5));

        mario = new Mario(this,ghost);
        //mario.setPosition(new Vec2(4,-5)); In levels

        CoinPickup pickup = new CoinPickup(this,game,mario);
        mario.addCollisionListener(pickup);



        GhostCollision Collision = new GhostCollision(mario);
        ghost.addCollisionListener(Collision);

        //MonsterCollision Collision1 = new MonsterCollision(mario);
        //monster.addCollisionListener(Collision1);

      /*  if(this instanceof Level3) {
            lava = new Lava(this, new Vec2(0, -12F), 0);
            LavaCollision lavaCollision = new LavaCollision(getMario());
            lava.addCollisionListener(lavaCollision);
        }*/



	}

    public Mario getMario() {
        return mario;
    }

    public Ghost getGhost() {
        return ghost;
    }

    public Monster getMonster(){return monster;}

    public Monster getMonster2() {
        return monster2;
    }

    public Lava getLava() {
        return lava;
    }

    //public Coin getCoin() {return coin;}

    public abstract boolean isComplete();

    public abstract Image getBackground();

    public abstract String getName();
}
