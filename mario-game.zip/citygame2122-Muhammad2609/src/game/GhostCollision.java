package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;

public class GhostCollision implements CollisionListener {

    private final Mario mario;

    public GhostCollision(Mario mario) {
        this.mario = mario;
    }

    @Override
    public void collide(CollisionEvent collisionEvent) {
        if(collisionEvent.getOtherBody() instanceof Mario){
            mario.setHealth(mario.getHealth()-1);
            if(mario.getHealth() == 0){
                collisionEvent.getOtherBody().destroy();
            }
        }
    }
}
