package game;

import org.jbox2d.common.Vec2;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Shooting implements MouseListener {

    private Mario mario;
    private final GameView view;
    public Shooting(Mario m, GameView v ) {
        mario = m ;
        view = v;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        Vec2 worldPoint = view.viewToWorld(e.getPoint());
        mario.shoot(worldPoint);
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    public void UpdateMario(Mario m){
        this.mario = m;
    }
}
